package com.managing.laptops.services.interfaces;

import java.util.List;

import com.managing.laptops.bo.LaptopUserDetails;

public interface AssetMgmtServiceIf {
	
	void createOrUpdate(LaptopUserDetails lapUserDetails) throws Exception;
	
	LaptopUserDetails getAssetDetail(Integer Id) throws Exception;
	
	List<LaptopUserDetails> getAllAssets() throws Exception;
	
}
