package com.managing.laptops.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.managing.laptops.bo.LaptopUserDetails;
import com.managing.laptops.helper.AsstMgmtHelper;
import com.managing.laptops.services.implementation.AssetMgmtServiceImpl;
import com.managing.laptops.services.interfaces.AssetMgmtServiceIf;
import com.managing.laptops.utils.HibernateUtil;

@Controller
public class AssetMgmtController {
	
	private final String FILE_NAME = "LAPTOP_DETAILS.CSV";
	
	private AssetMgmtServiceIf assetMgmtServiceIf; 
	
	public AssetMgmtController(){
		assetMgmtServiceIf = new AssetMgmtServiceImpl();
	}
	
	@InitBinder
	public void intiBinder (WebDataBinder binder){
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	dateFormat.setLenient(false);
	binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}


	@RequestMapping(value="addAsset", method=RequestMethod.GET)
	public String loadAsset(Model model){
		try {
			System.out.println("inside controller get method");
			model.addAttribute("asset",new LaptopUserDetails());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "addAsset";
	}
	
	@RequestMapping(value="addAsset", method=RequestMethod.POST)
	public String addOrUpdateAsset(@ModelAttribute("asset") LaptopUserDetails details, Model model)
	throws Exception{
//		try {
			System.out.println("inside controller post method");
			System.out.println(details);
			assetMgmtServiceIf.createOrUpdate(details);
		/*} catch (Exception e) {
			e.printStackTrace();
		}*/
		model.addAttribute("asset",new LaptopUserDetails());
		model.addAttribute("message", "Asset added successfully");
		return "addAsset";
	}
	
	@RequestMapping(value="getAssetList", method=RequestMethod.GET)
	public @ResponseBody List<LaptopUserDetails> getAllAssets(Model model){
		List<LaptopUserDetails> details = null;
		try {
			 details =  assetMgmtServiceIf.getAllAssets();
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("asset",details);
		return details;
	}
	
	@RequestMapping(value="updateAsset", method=RequestMethod.GET)
	public String getAssetDetail(@ModelAttribute("asset") LaptopUserDetails details, Model model, @RequestParam("id") int id){
		LaptopUserDetails detail = null;
		try {
			 detail =  assetMgmtServiceIf.getAssetDetail(id);
			 model.addAttribute("asset",detail);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("asset",detail);
		return "addAsset";
	}
	
	@RequestMapping(value="importData", method=RequestMethod.POST)
	public String bulkImport(@RequestParam("file") MultipartFile file){
		System.out.println("Import data" + file.getOriginalFilename());
		if(!file.isEmpty()){
			try {
				System.out.println("File not empty");
				byte[] bytes = file.getBytes();
				InputStream is = new ByteArrayInputStream(bytes);
				XSSFWorkbook workbook = new XSSFWorkbook(is);
				XSSFSheet sheet = workbook.getSheetAt(0);
				Iterator<Row> rowIterator = sheet.iterator();
				while (rowIterator.hasNext()){
					Row row = rowIterator.next();
					Iterator<Cell> cellIterator = row.cellIterator();
					 while (cellIterator.hasNext()){
						 Cell cell = cellIterator.next();
						 System.out.println(cell.getStringCellValue());
					 }
					 System.out.println("----------------------------------------");
				}
				is.close();
				System.out.println(bytes.length);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return "addAsset";
	}
	
	
	@RequestMapping(value="exportLaptopDetails", method=RequestMethod.POST)
	public void exportAsset(HttpServletResponse response){
		try {
				List<LaptopUserDetails> details = null;
				details =  assetMgmtServiceIf.getAllAssets();
				response.setContentType("text/csv");
				response.setHeader("Content-disposition", "attachment;filename="+FILE_NAME);
      			response.getOutputStream().println(AsstMgmtHelper.buildAssetCSV(response, details));
      			response.getOutputStream().flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@ExceptionHandler(Exception.class)

	public String handleEmployeeNotFoundException(HttpServletRequest request, Exception ex){

	return "error";

	} 


}
