package com.managing.laptops.services.implementation;

import java.util.List;

import com.managing.laptops.bo.LaptopUserDetails;
import com.managing.laptops.dao.implementation.AssetMgmtImpl;
import com.managing.laptops.dao.interfaces.AssetMgmtIf;
import com.managing.laptops.services.interfaces.AssetMgmtServiceIf;

public class AssetMgmtServiceImpl implements AssetMgmtServiceIf {
	
	private AssetMgmtIf assetMgmtIf;
	
	public AssetMgmtServiceImpl(){
		assetMgmtIf  = new AssetMgmtImpl();
	}

	public void createOrUpdate(LaptopUserDetails lapUserDetails) throws Exception {
		System.out.println("inside service method");
		assetMgmtIf.createOrUpdate(lapUserDetails);
	}

	public LaptopUserDetails getAssetDetail(Integer id) throws Exception {
		return assetMgmtIf.getAssetDetail(id);
	}

	public List<LaptopUserDetails> getAllAssets() throws Exception {
		return assetMgmtIf.getAllAssets();
	}

}
