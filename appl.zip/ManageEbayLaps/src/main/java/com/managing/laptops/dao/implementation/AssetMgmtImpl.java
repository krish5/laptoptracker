package com.managing.laptops.dao.implementation;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.managing.laptops.bo.LaptopUserDetails;
import com.managing.laptops.dao.interfaces.AssetMgmtIf;
import com.managing.laptops.utils.HibernateUtil;

public class AssetMgmtImpl implements AssetMgmtIf {

	private Session session;
	private Transaction transaction;
	
	public void createOrUpdate(LaptopUserDetails lapUserDetails) throws Exception {
		System.out.println("inside dao layer");
		
		session = HibernateUtil.getSessionFactory().openSession();
		transaction = session.beginTransaction();
		session.saveOrUpdate(lapUserDetails);
		transaction.commit();
		session.close();
	}

	public LaptopUserDetails getAssetDetail(Integer id) throws Exception {
		session = HibernateUtil.getSessionFactory().openSession();
		LaptopUserDetails lapUserDetails = (LaptopUserDetails) session.load(LaptopUserDetails.class, id);
		System.out.println("inside the dao impl~~~~~~~~>>>> " + lapUserDetails.toString());
		session.close();
		return lapUserDetails;
	}

	public List<LaptopUserDetails> getAllAssets() throws Exception {
		session = HibernateUtil.getSessionFactory().openSession();
		Query query = session.createQuery("from LaptopUserDetails");
		List<LaptopUserDetails> list = query.list();
		session.close();
		System.out.println("Number of Assets: "+list.size());
		return list;
	}

	public void update(LaptopUserDetails formData) throws Exception {
		session = HibernateUtil.getSessionFactory().openSession();
		transaction = session.beginTransaction();
		/*LaptopUserDetails lapUserDetails = (LaptopUserDetails) session.load(LaptopUserDetails.class, formData.getId());
		session.update(manipulateDetails(lapUserDetails, formData));*/
		session.update(formData);
		transaction.commit();
		session.close();
	}

	private LaptopUserDetails manipulateDetails(LaptopUserDetails dbData, LaptopUserDetails formData){
		dbData.setId(formData.getId());
		dbData.setUsername(formData.getUsername());
		dbData.setEbayId(formData.getEbayId());
		
		dbData.setLAssestTag(formData.getLAssestTag());
		dbData.setLServiceTag(formData.getLServiceTag());
		dbData.setLReceivedDate(formData.getLReceivedDate());
		
		dbData.setSwappedOn(formData.getSwappedOn());
		dbData.setSwappedTo(formData.getSwappedTo());
		dbData.setCognizantPoc(formData.getCognizantPoc());
		dbData.setCognizantId(formData.getCognizantId());
		return dbData;
	}
}
