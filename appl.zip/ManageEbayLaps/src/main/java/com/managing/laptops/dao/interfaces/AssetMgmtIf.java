package com.managing.laptops.dao.interfaces;

import java.util.List;

import com.managing.laptops.bo.LaptopUserDetails;

public interface AssetMgmtIf {

	void createOrUpdate(LaptopUserDetails lapUserDetails) throws Exception;
	
	LaptopUserDetails getAssetDetail(Integer id) throws Exception;
	
	List<LaptopUserDetails> getAllAssets() throws Exception;
	
}
