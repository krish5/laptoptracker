package com.managing.laptops.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.managing.laptops.bo.LaptopUserDetails;

public class AsstMgmtHelper {
	
	public static String buildAssetCSV(HttpServletResponse response, List<LaptopUserDetails> details) {
		
		String DELIMETER = ",";
		StringBuffer buffer=new StringBuffer();
  		buffer.append("ID,UserName,EbayId,CTS ID,LaptopAsset Tag,LaptopService Tag,LaptopRecieved Data,Swapped,Swapped To,CTS POC,Contact No");
  		buffer.append("\n");
  		
  		for(LaptopUserDetails detail : details){
  			buffer.append(detail.getId()+DELIMETER);
  			buffer.append(detail.getUsername()+DELIMETER);
  			buffer.append(detail.getEbayId()+DELIMETER);
  			buffer.append(detail.getCognizantId()+DELIMETER);
  			buffer.append(detail.getLAssestTag()+DELIMETER);
  			buffer.append(detail.getLServiceTag()+DELIMETER);
  			buffer.append(detail.getLReceivedDate()+DELIMETER);
  			buffer.append(detail.getSwapped()+DELIMETER);
  			buffer.append(detail.getSwappedTo()+DELIMETER);
  			buffer.append(detail.getCognizantPoc()+DELIMETER);
  			buffer.append(detail.getContactNo()+DELIMETER);
  			buffer.append("\n");
  		}
  		
		return buffer.toString();
	}

}
