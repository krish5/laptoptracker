$(document).ready(function () {
	var x = true;
	if($("#id").val() != "" ){
		var toggleWidth = $("#reg").width() == 500 ? "940px" : "500px";
   	    $("#reg").animate({ width: toggleWidth });
   		 $( ".frm" ).slideToggle("slow");
   	}
	
$(function() {
});

table = '<table id="datatable"> ';
tr = '<tr>';
td ='<td>';
th = '<th>';

_table = '</table>';
_tr = '</tr>';
_td = '</td>';
_th = '</th>';

header = '<thead>' 	+tr + th + 'Id' +_th
					+th + 'UserName' + _th

					+ th + 'Ebay Id' + _th

					+ th + 'Cognizant Id' + _th

					+ th + 'Laptop Received Date' + _th

					+ th + 'Asset Tag' + _th

					+ th + 'Service Tag' + _th

					+ th + 'Swapped On' + _th

					+ th + 'Swapped To' + _th

					+ th + 'Cognizant POC' + _th

					+ th + 'Cognizant No' + _th

					+ th + 'Update' + _th

					+ th + 'Delete' + _th + _tr  +'</thead>';
					

$("#loadData").click(function(){
	
	
	if(x){
		$.get("getAssetList", function(data, status){

			console.log(header);

			table += header + '<tbody>';

			$.each(data, function(key,value){

			var row = '<tr>';

			row += td + value.id + _td;

			row += td + value.username + _td;

			row += td + value.ebayId + _td;

			row += td + value.cognizantId + _td;

			row += td + value.lreceivedDate + _td;

			row += td + value.lassestTag + _td;

			row += td + value.lserviceTag + _td;

			row += td + value.swappedOn + _td;

			row += td + value.swappedTo + _td;

			row += td + value.cognizantPoc + _td;

			row += td + value.contactNo + _td; 

			row += td + "<a href='updateAsset?id="+value.id+"'> <img src='resources/images/update.png'/></a>"+ _td ;

			row += td + "<a href='deleteAsset?id="+value.id+"'> <img src='resources/images/delete.png'/></a>"+ _td + _tr;

			table +=row;

			});

			var html = table + '</tbody>' + _table;

			$('#assetTable').html(html);
			 $('#datatable').DataTable({
				 "columnDefs": [
				                {
				                    "targets": [ 0 ],
				                    "visible": false,
				                    "searchable": false
				                }]
			 });
			 $('div#assetTable').removeAttr('id');
			});
		x = false;
	}
	

	});

	});

