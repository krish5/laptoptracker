$(function() {
	
	/*  */
	 $( "#ebayId, #cognizantId, #contactNo" ).keypress(function(event){ 
			return isNumberKey(event);
		});
	
	 $( "#username" ).keypress(function(event){ 
			return isAlphabet(event);
		});
	 
	 $( "#subbtn" ).click(function(){ 
		 allEntryCheck();
		});
	 
	 $( "#LReceivedDate" ).datepicker();
	$( "#swappedOn" ).datepicker();
    
    
     $( "#reg" ).click(function(){
    	 var toggleWidth = $(this).width() == 500 ? "940px" : "500px";
         $(this).animate({ width: toggleWidth });
    	 $( ".frm" ).slideToggle("slow");
    });
     
     $( "#imprt" ).click(function(){
    	 $( ".impD" ).slideToggle("slow");
    });
     
     
     $( ".srch" ).click(function(){
    	 var toggleWidth = $(this).width() == 500 ? "940px" : "500px";
         $(this).animate({ width: toggleWidth });
         $(".astble").slideToggle("slow");
    });
  
     
  });

function isNumberKey(evt){
	   var charCode = (evt.which) ? evt.which : evt.keyCode;
	   if (charCode > 31 && (charCode < 48 || charCode > 57))
	      return false;

	   return true;
	}

function isAlphabet(evt){
	   var charCode = (evt.which) ? evt.which : evt.keyCode;
	   if (charCode > 31 && (charCode < 48 || charCode > 57))
	      return true;

	   return false;
	}

function allEntryCheck(){
	if($("#username").val()=="" || $("#ebayId").val()=="" || $("#cognizantId").val()=="" || $("#LReceivedDate").val()=="" ||
		$("#LAssestTag").val()=="" || $("#LServiceTag").val()=="" || $("#cognizantPoc").val()=="" || $("#contactNo").val()==""){
		$("#er").show();
		return false;
	}
	return true;
}